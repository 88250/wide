LiteIDE Golang Tools
=========

### LiteIDE

_LiteIDE is a simple, open source, cross-platform Go IDE._

### GoTools
_GoTools is a golang tools support for LiteIDE._

### Website
* LiteIDE Source code
<https://github.com/visualfc/liteide>
* Gotools Source code
<https://github.com/visualfc/gotools>
* Binary downloads 
<http://sourceforge.net/projects/liteide/files>
* Google group
<https://groups.google.com/group/liteide-dev>
* How to Install
<https://github.com/visualfc/liteide/blob/master/liteidex/deploy/welcome/en/install.md>
* FAQ
<https://github.com/visualfc/liteide/blob/master/liteidex/deploy/welcome/en/guide.md>
* Changes
<https://github.com/visualfc/liteide/blob/master/liteidex/deploy/welcome/en/changes.md>

### Donate
* <http://visualfc.github.com/support>
